## tests for the xfig device



xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=FALSE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=FALSE)

unlink("xfig-tests.fig")

## tests for the xfig device



xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=FALSE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=FALSE)

unlink("xfig-tests.fig")

## tests for the xfig device



xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=FALSE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=FALSE)

unlink("xfig-tests.fig")

## tests for the xfig device



xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=FALSE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=FALSE)

unlink("xfig-tests.fig")

## tests for the xfig device



xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=FALSE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=FALSE)

unlink("xfig-tests.fig")

## tests for the xfig device



xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=TRUE,textspecial=FALSE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=TRUE)

xfig("xfig-tests.fig",onefile=TRUE,defaultfont=FALSE,textspecial=FALSE)

unlink("xfig-tests.fig")

